<?php
/**
* @title			Minitek System Messages
* @copyright   		Copyright (C) 2011-2018 Minitek, All rights reserved.
* @license   		GNU General Public License version 3 or later.
* @author url   	https://www.minitek.gr/
* @developers   	Minitek.gr / Yannis Maragos
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

if(!defined('DS'))
{
	define('DS',DIRECTORY_SEPARATOR);
}

use Joomla\Registry\Registry;

class plgSystemMinitekSystemMessages extends JPlugin
{
	protected $autoloadLanguage = true;
	var $app;
	var $document;

	public function __construct(&$subject, $config)
	{
		$this->config = JFactory::getConfig();
		$this->app = JFactory::getApplication();
		$this->document = JFactory::getDocument();
		$this->user = JFactory::getUser();

		parent::__construct($subject, $config);
	}

	public function onAfterInitialise()
	{
		$jinput = $this->app->input;

		// Called via ajax
		if ($jinput->get('group') === 'system' && $jinput->get('plugin') === 'miniteksystemmessages' && $jinput->get('type') === 'checkSession')
		{
			if (!$this->user->id)
			{
				$messages = array();
				$messages[] = array('message' => JText::_('PLG_SYSTEM_MINITEK_SYSTEM_MESSAGES_USER_SESSION_EXPIRED'), 'type' => 'warning');

				jexit(json_encode($messages));
			}
			else
			{
				jexit(false);
			}
		}
	}

	public function onBeforeRender()
	{
		if (($this->app->isClient('administrator') && $this->params->get('enable_backend', false))
		|| ($this->app->isClient('site') && $this->params->get('enable_frontend', true)))
		{
			$messages = $this->app->getMessageQueue();

			$this->loadFrontendAssets($messages);
		}
	}

	public function onUserAfterLogin($options)
	{
		if ($this->app->isClient('site') && $this->params->get('login_message', false))
		{
			$this->app->enqueueMessage(JText::_('PLG_SYSTEM_MINITEK_SYSTEM_MESSAGES_SUCCESSFUL_LOGIN'), 'message');
		}
	}

	public function loadFrontendAssets($messages)
	{
		if ($this->app->isClient('site'))
		{
			$is_site = 'true';
		}
		else
		{
			$is_site = 'false';
		}

		if (!count($messages))
		{
			$messages = 'false';
		}
		else if ($messages)
		{
			// Group messages by type
			if ($this->params->get('group_messages', false))
			{
				$merged_messages = array();
				foreach ($messages as $message)
				{
					if (isset($merged_messages[$message['type']]))
					{
						$temp = $merged_messages[$message['type']];
						$temp['message'] .= '<br>'.$message['message'];
						$merged_messages[$message['type']] = $temp;
					}
					else
					{
						$merged_messages[$message['type']] = $message;
					}
				}
				$messages = array_values($merged_messages);
			}

			$messages = "'".addslashes(json_encode($messages))."'";
		}

		// Main css
		$this->document->addStyleSheet(JURI::root(true).'/plugins/system/miniteksystemmessages/assets/css/style.css?v=1.0.6');

		// Hide system message container
		if ($this->app->isClient('administrator') && $this->params->get('enable_backend', false))
		{
			$hide_in_admin = '.admin #system-message-container {
				display: none;
			}';
			$this->document->addStyleDeclaration($hide_in_admin);
		}

		if ($this->app->isClient('site') && $this->params->get('enable_frontend', true))
		{
			$hide_in_site = '#system-message-container {
				display: none;
			}';
			$this->document->addStyleDeclaration($hide_in_site);
		}

		// Colors
		// Message
		$message_background = $this->params->get('message_background', '#28c88a');
		$message_color = $this->params->get('message_color', '#ffffff');
		$message_icon = $this->params->get('message_icon', '#ffffff');
		$message_border = $this->params->get('message_border', '#2fad7f');
		if ($this->params->get('jgrowl_theme', 'default') == 'default')
		{
			$message_css = '.msm-message {
				background-color: '.$message_background.';
				color: '.$message_color.';
				border-color: '.$message_border.';
			}
			.msm-message .jGrowl-header i.fa {
				color: '.$message_icon.';
			}';
		}
		else if ($this->params->get('jgrowl_theme', 'default') == 'minimal')
		{
			$message_css = '.msm-message {
				background-color: '.$message_border.';
				color: '.$message_color.';
			}
			.msm-message .jGrowl-message {
				background-color: '.$message_background.';
			}
			.msm-message .jGrowl-header i.fa {
				color: '.$message_icon.';
			}';
		}
		$this->document->addStyleDeclaration($message_css);

		// Notice
		$notice_background = $this->params->get('notice_background', '#e1f4ff');
		$notice_color = $this->params->get('notice_color', '#4f90bf');
		$notice_icon = $this->params->get('notice_icon', '#4f90bf');
		$notice_border = $this->params->get('notice_border', '#87ccfa');
		if ($this->params->get('jgrowl_theme', 'default') == 'default')
		{
			$notice_css = '.msm-notice {
				background-color: '.$notice_background.';
				color: '.$notice_color.';
				border-color: '.$notice_border.';
			}
			.jGrowl-notification.msm-alert.msm-notice .jGrowl-close {
				border-color: '.$notice_border.';
			}
			.msm-notice .jGrowl-header i.fa {
				color: '.$notice_icon.';
			}';
		}
		else if ($this->params->get('jgrowl_theme', 'default') == 'minimal')
		{
			$notice_css = '.msm-notice {
				background-color: '.$notice_border.';
				color: '.$notice_color.';
			}
			.msm-notice .jGrowl-message {
				background-color: '.$notice_background.';
			}
			.msm-notice .jGrowl-header i.fa {
				color: '.$notice_icon.';
			}';
		}
		$this->document->addStyleDeclaration($notice_css);

		// Warning
		$warning_background = $this->params->get('warning_background', '#ed7248');
		$warning_color = $this->params->get('warning_color', '#ffffff');
		$warning_icon = $this->params->get('warning_icon', '#ffffff');
		$warning_border = $this->params->get('warning_border', '#d66437');
		if ($this->params->get('jgrowl_theme', 'default') == 'default')
		{
			$warning_css = '.msm-warning {
				background-color: '.$warning_background.';
				color: '.$warning_color.';
				border-color: '.$warning_border.';
			}
			.msm-warning .jGrowl-header i.fa {
				color: '.$warning_icon.';
			}';
		}
		else if ($this->params->get('jgrowl_theme', 'default') == 'minimal')
		{
			$warning_css = '.msm-warning {
				background-color: '.$warning_border.';
				color: '.$warning_color.';
			}
			.msm-warning .jGrowl-message {
				background-color: '.$warning_background.';
			}
			.msm-warning .jGrowl-header i.fa {
				color: '.$warning_icon.';
			}';
		}
		$this->document->addStyleDeclaration($warning_css);

		// Error
		$error_background = $this->params->get('error_background', '#eb6f57');
		$error_color = $this->params->get('error_color', '#ffffff');
		$error_icon = $this->params->get('error_icon', '#ffffff');
		$error_border = $this->params->get('error_border', '#f04124');
		if ($this->params->get('jgrowl_theme', 'default') == 'default')
		{
			$error_css = '.msm-error {
				background-color: '.$error_background.';
				color: '.$error_color.';
				border-color: '.$error_border.';
			}
			.msm-error .jGrowl-header i.fa {
				color: '.$error_icon.';
			}';
		}
		else if ($this->params->get('jgrowl_theme', 'default') == 'minimal')
		{
			$error_css = '.msm-error {
				background-color: '.$error_border.';
				color: '.$error_color.';
			}
			.msm-error .jGrowl-message {
				background-color: '.$error_background.';
			}
			.msm-error .jGrowl-header i.fa {
				color: '.$error_icon.';
			}';
		}
		$this->document->addStyleDeclaration($error_css);

		// [Close all] button
		$closer_background = $this->params->get('closer_background', '#333333');
		$closer_color = $this->params->get('closer_color', '#ffffff');
		$closer_border = $this->params->get('closer_border', '#000000');
		$closer_css = '.msm-jGrowl .jGrowl-closer {
			background-color: '.$closer_background.';
			color: '.$closer_color.';
			border-color: '.$closer_border.';
		}';
		$this->document->addStyleDeclaration($closer_css);

		// FontAwesome
		if ($this->params->get('load_fontawesome', true))
		{
			$this->document->addStyleSheet('https://netdna.bootstrapcdn.com/font-awesome/'.$this->params->get('fontawesome_version', '4.7.0').'/css/font-awesome.css');
		}

		JHtml::_('jquery.framework');

		// jGrowl
		if ($this->params->get('load_jgrowl', true))
		{
			$this->document->addStyleSheet(JURI::root(true).'/plugins/system/miniteksystemmessages/assets/css/jquery.jgrowl.css');
			$this->document->addScript(JURI::root(true).'/plugins/system/miniteksystemmessages/assets/js/jquery.jgrowl.js');
		}

		// Add javascript variables
		$this->document->addScriptDeclaration('window.miniteksystemmessages = {
			site_path: "'.JURI::root().'",
			is_site: '.$is_site.',
			lifetime: '.$this->config->get('lifetime').',
			user_id: "'.$this->user->id.'",
			jg_pool: "'.$this->params->get('jgrowl_pool', 0).'",
			jg_closer: "'.$this->params->get('jgrowl_closer', 1).'",
			jg_close_all: "'.JText::_('PLG_SYSTEM_MINITEK_SYSTEM_MESSAGES_CLOSE_ALL_TEXT').'",
			jg_sticky: "'.$this->params->get('jgrowl_sticky', 0).'",
			jg_theme: "'.$this->params->get('jgrowl_theme', 'default').'",
			jg_position: "'.$this->params->get('jgrowl_position', 'center').'",
			jg_glue: "'.$this->params->get('jgrowl_glue', 'after').'",
			jg_life: "'.$this->params->get('jgrowl_life', 3000).'",
			jg_closeDuration: "'.$this->params->get('jgrowl_closeduration', 500).'",
			jg_openDuration: "'.$this->params->get('jgrowl_openduration', 500).'",
			group_messages: "'.$this->params->get('group_messages', 0).'",
			joomla_container: "'.$this->params->get('joomla_container', 'system-message-container').'",
			messages: '.$messages.',
			error_text: "'.JText::_('ERROR').'",
			message_text: "'.JText::_('MESSAGE').'",
			notice_text: "'.JText::_('NOTICE').'",
			warning_text: "'.JText::_('WARNING').'",
		};');

		// Main js
		$this->document->addScript(JURI::root(true).'/plugins/system/miniteksystemmessages/assets/js/script.js?v=1.0.6');
	}
}
