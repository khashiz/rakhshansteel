(function($) {
	$(function(){
		
		var $site_path = window.miniteksystemmessages.site_path;
		var $is_site = window.miniteksystemmessages.is_site;
		if ($is_site != true)
		{
			$site_path = $site_path + 'administrator/';
		}
		var $lifetime = window.miniteksystemmessages.lifetime;
		var $user_id = window.miniteksystemmessages.user_id;
		var $jg_pool = parseInt(window.miniteksystemmessages.jg_pool, 10);
		var $jg_closer = window.miniteksystemmessages.jg_closer;
		var $jg_close_all = window.miniteksystemmessages.jg_close_all;
		var $jg_closerTemplate = '<div>[' + $jg_close_all + ']<\/div>';
		var $jg_sticky = window.miniteksystemmessages.jg_sticky;
		var $jg_theme = 'msm-' + window.miniteksystemmessages.jg_theme;
		var $jg_position = window.miniteksystemmessages.jg_position;
		var $jg_glue = window.miniteksystemmessages.jg_glue;
		var $jg_life = parseInt(window.miniteksystemmessages.jg_life, 10);
		var $jg_closeDuration = parseInt(window.miniteksystemmessages.jg_closeDuration, 10);
		var $jg_openDuration = parseInt(window.miniteksystemmessages.jg_openDuration, 10);
		var $group_messages = window.miniteksystemmessages.group_messages;
		var $joomla_container = window.miniteksystemmessages.joomla_container;
		var $messages = window.miniteksystemmessages.messages;
		var $error_text = window.miniteksystemmessages.error_text;
		var $message_text = window.miniteksystemmessages.message_text;
		var $notice_text = window.miniteksystemmessages.notice_text;
		var $warning_text = window.miniteksystemmessages.warning_text;
		
		// Creates jGrowl popup
		$.jGrowl.defaults.pool = $jg_pool;
		$.jGrowl.defaults.closer = $jg_closer;
		$.jGrowl.defaults.closerTemplate = $jg_closerTemplate;

		function createMinitekMessage(text, type, sticky)
		{
			$header = $notice_text;
			$theme = 'msm-alert msm-notice';
			
			if (type == 'error' || type == 'danger')
			{
				$header = '<i class=\"fa fa-times-circle\"><\/i> <span class=\"msm-title\">' + $error_text + '<\/span>';
				$theme = 'msm-alert msm-error';
			}
			else if (type == 'message' || type == 'success')
			{
				$header = '<i class=\"fa fa-check-circle\"><\/i> <span class=\"msm-title\">' + $message_text + '<\/span>';
				$theme = 'msm-alert msm-message';
			}
			else if (type == 'notice' || type == 'info')
			{
				$header = '<i class=\"fa fa-info-circle\"><\/i> <span class=\"msm-title\">' + $notice_text + '<\/span>';
				$theme = 'msm-alert msm-notice';
			}
			else if (type == 'warning')
			{
				$header = '<i class=\"fa fa-exclamation-circle\"><\/i> <span class=\"msm-title\">' + $warning_text + '<\/span>';
				$theme = 'msm-alert msm-warning';
			} 
			
			if ($jg_sticky == 0 && sticky != true)
			{
				var sticky = false;
			}
			else
			{
				var sticky = true;
			}

			var jgrowl_popup = $.jGrowl(text, {
				pool: $jg_pool,
				header: $header,
				group: '',
				sticky: sticky,
				position: $jg_position + ' msm-jGrowl ' + $jg_theme,
				appendTo: 'body',
				glue: $jg_glue,
				theme: $theme,
				themeState: '',
				corners: '10px',
				check: 250,
				life: $jg_life,
				closeDuration: $jg_closeDuration,
				openDuration: $jg_openDuration,
				easing: 'swing',
				closer: true,
				closeTemplate: 'x',
				closerTemplate: '',
				animateOpen: {opacity: 'show'},
				animateClose: {opacity: 'hide'}
			});	
		}

		// Remove Joomla system messages container
		$('#'+$joomla_container).empty();
				
		// Display messages
		if ($messages != false)
		{
			var system_messages = JSON.parse($messages);
			
			system_messages.forEach(function(element) 
			{
				createMinitekMessage(element.message, element.type);
			});
		}
		
		// Checks for expired user session
		function checkSession()
		{
			$.ajax(
			{
				type: "POST",
				url: $site_path+"index.php?group=system&plugin=miniteksystemmessages&type=checkSession"
			}).done(function(response) 
			{
				if (response)
				{
					var session_message = JSON.parse(response);
					
					session_message.forEach(function(element) 
					{
						createMinitekMessage(element.message, element.type, true);
					}); 
				}
				else
				{
					var lifetime = (parseInt($lifetime, 10) * 60000) + 1000;
					setTimeout(function(){checkSession();}, parseInt(lifetime, 10));	
				}
				
			}).fail(function(jqXHR, exception) 
			{

				var msg = '';
				if (jqXHR.status === 0) {
					msg = 'No connection. Verify Network.';
				} else if (jqXHR.status == 404) {
					msg = 'Requested page not found. [404]';
				} else if (jqXHR.status == 500) {
					msg = 'Internal Server Error [500].';
				} else if (exception === 'parsererror') {
					msg = 'Requested JSON parse failed.';
				} else if (exception === 'timeout') {
					msg = 'Time out error.';
				} else if (exception === 'abort') {
					msg = 'Ajax request aborted.';
				} else {
					msg = 'Uncaught Error.' + jqXHR.responseText;
				}
			});	
		}
		
		if ($user_id > 0)
		{		
			checkSession();
		}
				
		// Create an observer instance - Observes the system-message-container for newly added messages
		var system_container = $('#'+$joomla_container)[0];
		
		if ($('#'+$joomla_container).length > 0) 
		{
			var observer = new MutationObserver(function( mutations ) 
			{
				mutations.forEach(function( mutation ) 
				{
					var newNodes = mutation.addedNodes; // DOM NodeList
					if (newNodes !== null) { // If there are new nodes added
						var $nodes = $(newNodes);
						$nodes.each(function() 
						{
							var $_sticky;
							var $node = $(this);
							if ($node.hasClass("alert")) 
							{
								var $node_class = $node[0].className;
								var $class_type = $node_class.substr($node_class.indexOf("-") + 1); // Get alert type
								if ($class_type == 'error alert-joomlaupdate')
								{
									$class_type = 'notice';
									var $children_div = $node;
									$_sticky = true;
								}
								else
								{
									var $children_div = $node.children('div'); // Get children div
								}
							
								// Group children
								if ($group_messages == true) 
								{
									var $merged_messages = '';
									$children_div.each(function() 
									{
										var $child_div = $(this);
										$merged_messages += $child_div[0].innerHTML +'<br>'; // Get div text
										
									});
									createMinitekMessage($merged_messages, $class_type, $_sticky);
								} 
								else 
								{
									$children_div.each(function() 
									{
										var $child_div = $(this);
										$div_content = $child_div[0].innerHTML; // Get div text
										createMinitekMessage($div_content, $class_type, $_sticky);
									});
								}
							}
						}); 
					}
				});  
			});
		
			// Configuration of the observer:
			var config = { 
				attributes: true, 
				childList: true, 
				characterData: true 
			};
		
			// Pass in the target node, as well as the observer options
			observer.observe(system_container, config);
		}		
	})
})(jQuery);


